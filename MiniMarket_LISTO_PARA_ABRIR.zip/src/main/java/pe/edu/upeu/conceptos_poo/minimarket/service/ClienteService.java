package pe.edu.upeu.conceptos_poo.minimarket.service;

import pe.edu.upeu.conceptos_poo.minimarket.dto.ModeloDataAutocomplet;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Cliente;

import java.util.List;

public interface ClienteService extends CRUD_GenericoSefvice_Interface<Cliente, String> {
    List<ModeloDataAutocomplet> listAutoCompletCliente();
}
