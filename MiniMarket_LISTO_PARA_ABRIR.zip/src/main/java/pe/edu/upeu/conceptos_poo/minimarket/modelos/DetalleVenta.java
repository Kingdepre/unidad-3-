package pe.edu.upeu.conceptos_poo.minimarket.modelos;



import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;




@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table (name = "minimarket_detalle_venta")
public class DetalleVenta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_detalle_venta;

    @ManyToOne(fetch = FetchType.EAGER) // Carga el producto junto con el detalle
    @JoinColumn(name = "id_producto", nullable = false)
    private Producto producto;

    @Column(name = "cantidad", nullable = false)
    private int cantidad;

    @Column(name = "precio_unitario", nullable = false)
    private double precioUnitario;

    @Column(name = "subtotal_producto", nullable = false)
    private double subtotalProducto;

    @ManyToOne
    @JoinColumn(name = "id_venta", nullable = false)
    @JsonIgnore // Evita bucles infinitos al serializar Venta
    private Venta venta;
}