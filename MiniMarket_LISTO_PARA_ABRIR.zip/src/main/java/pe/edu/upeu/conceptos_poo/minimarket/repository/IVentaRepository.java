package pe.edu.upeu.conceptos_poo.minimarket.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Venta;

import java.time.LocalDateTime; // Importar
import java.util.List; // Importar

@Repository
public interface IVentaRepository extends ICrudGenericoRepository<Venta, Long> {
    @Query("SELECT v FROM Venta v WHERE v.fechaGeneracion BETWEEN :inicio AND :fin ORDER BY v.fechaGeneracion ASC")
    List<Venta> findVentasByFechaGeneracionBetween(
            @Param("inicio") LocalDateTime inicio,
            @Param("fin") LocalDateTime fin
    );
}