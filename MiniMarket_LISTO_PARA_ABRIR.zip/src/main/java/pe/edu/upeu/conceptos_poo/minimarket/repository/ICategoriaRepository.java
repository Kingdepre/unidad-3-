package pe.edu.upeu.conceptos_poo.minimarket.repository;

import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Categoria;
@Repository
public interface ICategoriaRepository extends ICrudGenericoRepository<Categoria,Long>{

}
