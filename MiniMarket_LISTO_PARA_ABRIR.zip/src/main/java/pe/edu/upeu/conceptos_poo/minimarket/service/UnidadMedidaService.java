package pe.edu.upeu.conceptos_poo.minimarket.service;

import pe.edu.upeu.conceptos_poo.minimarket.dto.ComboBoxOption;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.UnidadMedida;

import java.util.List;

public interface UnidadMedidaService extends CRUD_GenericoSefvice_Interface<UnidadMedida, Long>{
    List<ComboBoxOption> listarCombobox();
}
