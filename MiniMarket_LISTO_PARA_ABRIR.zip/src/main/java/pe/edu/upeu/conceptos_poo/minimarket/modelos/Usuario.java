package pe.edu.upeu.conceptos_poo.minimarket.modelos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Table(name = "minimarket_usuario") // Esta tabla se llama 'minimarket_usuario' en el DB file
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario") // <--- CORREGIDO (antes 'id' implícito)
    private Long id;

    @Column(name = "nombre_user", nullable = false, unique = true) // <--- CORREGIDO (antes 'correo')
    private String correo;

    @Column(name = "clave", nullable = false) // <--- CORREGIDO (antes 'password')
    private String password;

    @Column(name = "rol", nullable = false)
    private String rol;

    @ManyToOne
    @JoinColumn(name = "id_perfil", nullable = false)
    private Perfil perfil;
}