package pe.edu.upeu.conceptos_poo.minimarket.modelos;



import jakarta.persistence.*;
import lombok.Data;



@Entity
@Data
@Table(name = "minimarket_perfil")
public class Perfil {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_perfil")
    private Long idPerfil;

    @Column(name = "correo", nullable = false, unique = true)
    private String correo;
}