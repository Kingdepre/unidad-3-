package pe.edu.upeu.conceptos_poo.minimarket.service;

import pe.edu.upeu.conceptos_poo.minimarket.modelos.Compra;
import java.time.LocalDateTime;
import java.util.List;

public interface CompraService extends CRUD_GenericoSefvice_Interface<Compra, Long> {
    Compra registrarCompra(Compra compra);

    List<Compra> findComprasBetweenFechas(LocalDateTime inicio, LocalDateTime fin);
}