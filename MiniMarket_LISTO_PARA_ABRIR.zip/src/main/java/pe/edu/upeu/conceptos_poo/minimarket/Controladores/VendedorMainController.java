package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.components.StageManager;
import java.io.IOException;
import java.util.prefs.Preferences;

@Controller
public class VendedorMainController {
    @Autowired private ConfigurableApplicationContext applicationContext;

    @FXML private BorderPane bpVendedorMain;
    @FXML private TabPane tabPaneVendedor;
    @FXML private Menu menuEstilo;
    @FXML private Menu menuIdioma;

    private ComboBox<String> comboBoxEstilos;
    Preferences userPrefs = Preferences.userRoot().node("pe/edu/upeu/minimarket/prefs");

    @FXML public void initialize() {
        abrirCaja(null); // Primer paso del vendedor
        configurarMenuEstilo();
    }

    // --- MENÚ ACCIONES ---
    @FXML private void abrirCaja(ActionEvent event) { abrirTabConFXML("/fxml/apertura_cierre_caja.fxml", "Caja"); }
    @FXML private void abrirRegistroVenta(ActionEvent event) { abrirTabConFXML("/fxml/cliente_main.fxml", "Registrar Venta"); }
    @FXML private void abrirHistorialVentas(ActionEvent event) { abrirTabConFXML("/fxml/historial_ventas.fxml", "Historial"); }
    @FXML private void abrirGestionClientes(ActionEvent event) { abrirTabConFXML("/fxml/gestionar_clientes.fxml", "Clientes"); }
    @FXML private void abrirReporteVentas(ActionEvent event) { abrirTabConFXML("/fxml/reportes_main.fxml", "Reportes"); }
    @FXML private void abrirBuscadorPrecios(ActionEvent event) { abrirTabConFXML("/fxml/buscador_precios.fxml", "Consulta Precios"); }
    @FXML private void abrirCambioClave(ActionEvent event) { abrirTabConFXML("/fxml/cambio_clave.fxml", "Cambiar Contraseña"); }

    @FXML
    private void cerrarSesion(ActionEvent event) {
        try {
            Stage stage = StageManager.getPrimaryStage();
            if (stage == null) stage = (Stage) bpVendedorMain.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            fxmlLoader.setControllerFactory(applicationContext::getBean);
            Parent loginRoot = fxmlLoader.load();
            Scene scene = new Scene(loginRoot);
            stage.setScene(scene);
            stage.setTitle("MiniMarket - Iniciar Sesión");
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML private void salirAplicacion(ActionEvent event) { Platform.exit(); System.exit(0); }

    // --- UTILITARIOS ---
    private void abrirTabConFXML(String fxmlPath, String tituloTab) {
        for (Tab tab : tabPaneVendedor.getTabs()) {
            if (tab.getText().equals(tituloTab)) {
                tabPaneVendedor.getSelectionModel().select(tab);
                return;
            }
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            loader.setControllerFactory(applicationContext::getBean);
            Parent root = loader.load();
            Tab nuevaPestana = new Tab(tituloTab);
            nuevaPestana.setContent(root);
            tabPaneVendedor.getTabs().add(nuevaPestana);
            tabPaneVendedor.getSelectionModel().select(nuevaPestana);
        } catch (IOException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Error cargando vista: " + e.getMessage()).show();
        }
    }

    private void configurarMenuEstilo() {
        comboBoxEstilos = new ComboBox<>(FXCollections.observableArrayList("Estilo por Defecto", "Estilo Oscuro", "Estilo Azul", "Estilo Verde", "Estilo Rosado"));
        comboBoxEstilos.setValue(userPrefs.get("appEstilo", "Estilo por Defecto"));
        comboBoxEstilos.setOnAction(e -> cambiarEstilo());
        CustomMenuItem item = new CustomMenuItem(comboBoxEstilos);
        item.setHideOnClick(false);
        menuEstilo.getItems().add(item);
    }
    private void cambiarEstilo() { /* Igual que Admin */ }
}
