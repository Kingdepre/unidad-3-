package pe.edu.upeu.conceptos_poo.minimarket.modelos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
@Table(name = "minimarket_producto") // Esta tabla se llama 'minimarket_producto' en el DB file
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_producto;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "\"precio_u_\"", nullable = false) // <--- CORREGIDO (antes 'precio_u', se añaden comillas por el '_')
    private Double PrecioU;

    @Column(name = "stock", nullable = false) // <--- CORREGIDO (antes 'stok')
    private Long stok;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_categoria", nullable = false)
    private Categoria categoria;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_unidad", nullable = false) // <--- CORREGIDO (antes 'id_unidad_medida')
    private UnidadMedida unidadMedida;
}