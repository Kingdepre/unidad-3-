package pe.edu.upeu.conceptos_poo.minimarket.modelos;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "minimarket_u_medida") // <--- CORREGIDO (antes 'MiniMarket_Unidad_Medida')
public class UnidadMedida {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_unidad") // <--- CORREGIDO (antes 'id_unidad_medida')
    private Long id_unidad;

    @Column(name = "nombre_medida", nullable = false, unique = true) // <--- CORREGIDO (antes 'nombre')
    private String nombre_medida;
}