package pe.edu.upeu.conceptos_poo.minimarket.service;

import net.sf.jasperreports.engine.JasperPrint;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import java.time.LocalDate;
import java.util.List;

public interface ReportService {
    JasperPrint generarReporteVentas(LocalDate fechaInicio, LocalDate fechaFin);
    byte[] generarBoletaPdf(Long idVenta);

    byte[] generarProformaPdf(List<Producto> productos);
}