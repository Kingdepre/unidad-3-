package pe.edu.upeu.conceptos_poo.minimarket.utils;

import javax.print.*;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class PrinterUtil {

    /**
     * Obtiene una lista de los nombres de todas las impresoras conectadas.
     * @return Lista de nombres de impresoras.
     */
    public static List<String> getImpresoras() {
        List<String> impresoras = new ArrayList<>();
        PrintService[] printServices = PrintServiceLookup.lookupPrintServices(null, null);
        for (PrintService printService : printServices) {
            impresoras.add(printService.getName());
        }
        return impresoras;
    }

    /**
     * Imprime un texto plano en la impresora especificada.
     * @param texto El string completo a imprimir (tu boleta).
     * @param nombreImpresora El nombre exacto de la impresora.
     * @throws PrintException Si ocurre un error durante la impresión.
     */
    public static void imprimirTexto(String texto, String nombreImpresora) throws PrintException {
        PrintService printService = null;

        // Buscar la impresora por su nombre
        PrintService[] printServices = PrintServiceLookup.lookupPrintServices(null, null);
        for (PrintService service : printServices) {
            if (service.getName().equalsIgnoreCase(nombreImpresora)) {
                printService = service;
                break;
            }
        }

        if (printService == null) {
            throw new PrintException("Impresora no encontrada: " + nombreImpresora);
        }

        // Crear el trabajo de impresión
        DocPrintJob job = printService.createPrintJob();

        // Convertir el texto a un stream de bytes
        InputStream stream = new ByteArrayInputStream(texto.getBytes(StandardCharsets.UTF_8));

        // Especificar que el formato es texto plano
        DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;

        // Crear el documento
        Doc doc = new SimpleDoc(stream, flavor, null);

        // Definir atributos (podemos dejarlo vacío para default)
        PrintRequestAttributeSet attrs = new HashPrintRequestAttributeSet();

        // Enviar a imprimir
        job.print(doc, attrs);
    }
}