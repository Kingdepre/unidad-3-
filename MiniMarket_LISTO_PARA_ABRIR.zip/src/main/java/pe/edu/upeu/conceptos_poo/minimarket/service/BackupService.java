package pe.edu.upeu.conceptos_poo.minimarket.service;

import org.springframework.stereotype.Service;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class BackupService {

    private static final String DB_PATH = "data/MiniMarket.db"; // Ruta relativa de tu BD

    public void realizarBackup(File destinoDirectorio) throws Exception {
        File dbFile = new File(DB_PATH);
        if (!dbFile.exists()) {
            throw new Exception("No se encuentra el archivo de base de datos en: " + DB_PATH);
        }

        String timeStamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String backupFileName = "Backup_MiniMarket_" + timeStamp + ".db";
        File backupFile = new File(destinoDirectorio, backupFileName);

        Files.copy(dbFile.toPath(), backupFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }
}
