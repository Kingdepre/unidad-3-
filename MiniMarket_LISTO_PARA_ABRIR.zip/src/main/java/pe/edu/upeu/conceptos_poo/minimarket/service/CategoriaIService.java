package pe.edu.upeu.conceptos_poo.minimarket.service;

import javafx.scene.control.ComboBox;
import pe.edu.upeu.conceptos_poo.minimarket.dto.ComboBoxOption;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Categoria;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICrudGenericoRepository;

import java.util.List;

public interface CategoriaIService extends CRUD_GenericoSefvice_Interface<Categoria, Long> {
    List<ComboBoxOption> listarCombobox();
}
