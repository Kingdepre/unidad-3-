package pe.edu.upeu.conceptos_poo.minimarket.service.imp;

// --- Importaciones Corregidas para Spring 3 ---
import jakarta.transaction.Transactional;
// --- Fin de Corrección ---

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.DetalleVenta;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Producto;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Venta;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.minimarket.repository.IVentaRepository;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProductoIService;
import pe.edu.upeu.conceptos_poo.minimarket.service.VentaService;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VentaServiceImp extends CRUD_GenericoServiceImp<Venta, Long> implements VentaService {

    private final IVentaRepository ventaRepository;
    private final ProductoIService productoService; // Para actualizar stock

    @Override
    protected ICrudGenericoRepository<Venta, Long> getRepository() {
        return ventaRepository;
    }

    @Override
    @Transactional // Esta anotación ahora usa jakarta.transaction.Transactional
    public Venta registrarVentaCompleta(Venta venta) throws RuntimeException {

        List<DetalleVenta> detalles = venta.getDetalleVentas();

        // 1. Validar y actualizar stock PRIMERO
        for (DetalleVenta detalle : detalles) {
            Producto producto = productoService.findProductoById(detalle.getProducto().getId_producto());
            if (producto == null) {
                throw new RuntimeException("Producto no encontrado: " + detalle.getProducto().getNombre());
            }

            long nuevoStock = producto.getStok() - detalle.getCantidad();
            if (nuevoStock < 0) {
                throw new RuntimeException("Stock insuficiente para: " + producto.getNombre());
            }

            producto.setStok(nuevoStock);
            productoService.updateProducto(producto);

            // Establecemos la relación bidireccional ANTES de guardar.
            detalle.setVenta(venta);
        }

        // 2. Guardar la Venta (y los detalles en cascada)
        Venta ventaGuardada = ventaRepository.save(venta);
        return ventaGuardada;
    }

    @Override
    public List<Venta> findVentasBetweenFechas(LocalDateTime inicio, LocalDateTime fin) {
        return ventaRepository.findVentasByFechaGeneracionBetween(inicio, fin);
    }
}