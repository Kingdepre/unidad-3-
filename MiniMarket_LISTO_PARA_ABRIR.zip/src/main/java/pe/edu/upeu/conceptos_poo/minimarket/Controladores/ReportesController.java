package pe.edu.upeu.conceptos_poo.minimarket.Controladores;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import net.sf.jasperreports.engine.JasperPrint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.conceptos_poo.minimarket.components.ReportDialog; // Usamos el visor que ya existe
import pe.edu.upeu.conceptos_poo.minimarket.service.ReportService;

import java.time.LocalDate;

@Controller
public class ReportesController {

    @FXML private DatePicker dpFechaInicio;
    @FXML private DatePicker dpFechaFin;
    @FXML private Button btnGenerarReporteVentas;

    @Autowired
    private ReportService reportService; // Inyectamos el servicio de reportes

    @FXML
    public void initialize() {
        // Inicializar fechas por defecto (ej. el día de hoy)
        dpFechaInicio.setValue(LocalDate.now());
        dpFechaFin.setValue(LocalDate.now());
    }

    @FXML
    private void generarReporteVentas() {
        LocalDate fechaInicio = dpFechaInicio.getValue();
        LocalDate fechaFin = dpFechaFin.getValue();

        if (fechaInicio == null || fechaFin == null) {
            mostrarAlerta("Error", "Debe seleccionar una fecha de inicio y fin.", Alert.AlertType.ERROR);
            return;
        }
        if (fechaFin.isBefore(fechaInicio)) {
            mostrarAlerta("Error", "La fecha de fin no puede ser anterior a la fecha de inicio.", Alert.AlertType.ERROR);
            return;
        }

        try {
            // 1. Llamar al servicio para generar el reporte
            JasperPrint jasperPrint = reportService.generarReporteVentas(fechaInicio, fechaFin);

            if (jasperPrint == null) {
                mostrarAlerta("Error", "El objeto JasperPrint es nulo. Revisa el ReportService.", Alert.AlertType.ERROR);
                return;
            }

            // 2. Mostrar el reporte en el visor (ReportDialog ya existe en tu proyecto)
            ReportDialog reportDialog = new ReportDialog(jasperPrint);
            reportDialog.show(); // Mostrar el diálogo del visor de reportes

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Error al generar reporte", "No se pudo generar el reporte: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}