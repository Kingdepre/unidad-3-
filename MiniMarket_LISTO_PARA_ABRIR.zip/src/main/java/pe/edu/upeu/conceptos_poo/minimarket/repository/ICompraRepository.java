package pe.edu.upeu.conceptos_poo.minimarket.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Compra;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ICompraRepository extends ICrudGenericoRepository<Compra, Long> {

    // Consulta personalizada para buscar compras en un rango de fechas
    @Query("SELECT c FROM Compra c WHERE c.fechaEmision BETWEEN :inicio AND :fin ORDER BY c.fechaEmision ASC")
    List<Compra> findComprasByFechaEmisionBetween(
            @Param("inicio") LocalDateTime inicio,
            @Param("fin") LocalDateTime fin
    );
}