package pe.edu.upeu.conceptos_poo.minimarket.repository;

import org.springframework.stereotype.Repository;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Proveedor;

@Repository
public interface IProveedorRepository extends ICrudGenericoRepository<Proveedor, Long> {
}