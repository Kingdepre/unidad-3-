package pe.edu.upeu.conceptos_poo.minimarket.repository;

import pe.edu.upeu.conceptos_poo.minimarket.modelos.Perfil;

public interface IPerfilRepository extends ICrudGenericoRepository<Perfil,Long>{
}
