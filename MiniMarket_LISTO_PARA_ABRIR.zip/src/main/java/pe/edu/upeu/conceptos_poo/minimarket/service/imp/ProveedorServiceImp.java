package pe.edu.upeu.conceptos_poo.minimarket.service.imp;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pe.edu.upeu.conceptos_poo.minimarket.modelos.Proveedor;
import pe.edu.upeu.conceptos_poo.minimarket.repository.ICrudGenericoRepository;
import pe.edu.upeu.conceptos_poo.minimarket.repository.IProveedorRepository;
import pe.edu.upeu.conceptos_poo.minimarket.service.ProveedorService;

@Service
@RequiredArgsConstructor
public class ProveedorServiceImp extends CRUD_GenericoServiceImp<Proveedor, Long> implements ProveedorService {

    private final IProveedorRepository proveedorRepository;

    @Override
    protected ICrudGenericoRepository<Proveedor, Long> getRepository() {
        return proveedorRepository;
    }
}