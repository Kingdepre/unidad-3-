package pe.edu.upeu.conceptos_poo.minimarket.modelos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "minimarket_venta") // Este nombre de tabla también es inconsistente con el .db, pero el @JoinColumn es el error crítico
public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idVenta;

    @Column(name = "fecha_generacion", nullable = false)
    private LocalDateTime fechaGeneracion;

    @ManyToOne
    @JoinColumn(name = "dni_ruc_cliente", nullable = false) // <--- CORREGIDO
    // ----- FIN DE LA MODIFICACIÓN -----
    private Cliente cliente;

    @Column(name = "tipo_documento", nullable = false)
    private String tipoDocumento; // BOLETA o FACTURA

    @Column(name = "serie", nullable = false)
    private String serie;

    @Column(name = "subtotal", nullable = false)
    private double subtotal;

    @Column(name = "igv", nullable = false)
    private double igv;

    @Column(name = "total", nullable = false)
    private double total;

    @OneToMany(mappedBy = "venta", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<DetalleVenta> detalleVentas;
}