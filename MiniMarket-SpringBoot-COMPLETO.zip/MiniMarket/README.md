# 🛒 MiniMarket — Sistema de Gestión y Ventas

Proyecto del curso **Programación Orientada a Objetos (POO)** — Ciclo VI · 2026-1 · **Grupo G1**
Escuela Profesional de Ingeniería de Sistemas — **Universidad Peruana Unión (UPeU)**

Aplicación de **escritorio** para administrar un minimarket: autenticación por rol (Administrador, Vendedor, Cliente), gestión de productos, ventas con cálculo de **IGV** y control de stock, compras, clientes, proveedores, caja y reportes en PDF.

---

## ✨ Características

- 🔐 **Autenticación segura** con Spring Security (**BCrypt**) y enrutamiento por rol.
- 📦 **CRUD completo**: productos, categorías, unidades de medida, clientes, proveedores, usuarios.
- 🧾 **Ventas** con carrito, **IGV (18%)**, descuento de stock y registro **transaccional**.
- 🛍️ **Compras** a proveedores con su detalle.
- 💵 **Caja**: apertura y cierre por turno.
- 📊 **Reportes y comprobantes en PDF** con **JasperReports**.
- 🔎 **Consulta de DNI** y **envío de correos** (Spring Mail).
- 🗄️ **Base de datos SQLite** embebida, incluida con datos de ejemplo.

---

## 🏗️ Arquitectura

Arquitectura **en capas** con **inyección de dependencias de Spring**:

```
Vista (JavaFX: FXML + CSS)
        │
Controlador (@Controller)        ← eventos de la UI
        │
Servicio (@Service / *.imp)      ← lógica de negocio (@Transactional)
        │
Repositorio (Spring Data JPA)    ← acceso a datos
        │
Modelo (@Entity JPA)             ← entidades del dominio
```

- **Repositorio genérico:** `ICrudGenericoRepository<T, ID> extends JpaRepository<T, ID>` → CRUD heredado sin SQL manual.
- **Servicio genérico:** `CRUD_GenericoServiceImp<T, ID>` centraliza la lógica común.
- **Spring Boot + JavaFX:** Spring arranca en modo escritorio (`WebApplicationType.NONE`) y los controladores JavaFX son beans de Spring.

---

## 🧰 Tecnologías

| Tecnología | Uso |
|---|---|
| **Java 17** | Lenguaje base |
| **Spring Boot 3.5** | Inyección de dependencias y arranque |
| **Spring Data JPA + Hibernate** | Persistencia sin SQL manual |
| **Spring Security (BCrypt)** | Encriptación de contraseñas |
| **JavaFX** | Interfaz gráfica (FXML + CSS) |
| **SQLite** | Base de datos embebida (archivo) |
| **JasperReports** | Reportes y comprobantes en PDF |
| **Spring Mail (JavaMail)** | Envío de correos |
| **Lombok** | Reducción de código repetitivo |
| **Maven** | Build y gestión de dependencias |

---

## ✅ Requisitos

- **JDK 17** o superior
- **Maven 3.8+**
- (Opcional) Conexión a internet para consulta de DNI y envío de correos

---

## 🚀 Cómo ejecutar

```bash
cd MiniMarket
mvn spring-boot:run
```

O ejecute la clase principal `pe.edu.upeu.conceptos_poo.minimarket.Application` desde su IDE.

> El sistema arranca Spring Boot en modo escritorio y luego carga la interfaz JavaFX. La base de datos SQLite (`data/MiniMarket.db`) ya viene con datos de ejemplo.

### 👤 Usuarios de prueba

| Correo | Rol |
|---|---|
| `admin@minimarket.com` | Administrador |
| `cajero@minimarket.com` | Vendedor |
| `cliente@gmail.com` | Cliente |

> Las contraseñas se guardan **encriptadas con BCrypt**. Use la contraseña definida por su equipo (por convención del proyecto, del tipo `usuario123`). El administrador puede restablecerlas desde **Gestión de Usuarios**.

---

## ⚙️ Configuración (importante)

El archivo `src/main/resources/application.properties` usa **variables de entorno** para las credenciales de correo, de modo que **no se exponen contraseñas en el código**:

```properties
spring.mail.username=${MAIL_USERNAME:}
spring.mail.password=${MAIL_PASSWORD:}
```

Para habilitar el envío de correos, defina las variables antes de ejecutar:

```bash
# Linux / macOS
export MAIL_USERNAME="tu_correo@gmail.com"
export MAIL_PASSWORD="tu_app_password"

# Windows (PowerShell)
$env:MAIL_USERNAME="tu_correo@gmail.com"
$env:MAIL_PASSWORD="tu_app_password"
```

> Si no se definen, el sistema funciona igual; solo se desactiva el envío de correos.

---

## 🗂️ Estructura del proyecto

```
MiniMarket/
├── pom.xml
├── data/MiniMarket.db                 # Base de datos SQLite con datos
├── jasper/                            # Plantillas .jrxml de reportes
└── src/main/
    ├── java/pe/edu/upeu/conceptos_poo/minimarket/
    │   ├── Application.java            # Punto de entrada
    │   ├── MiniMarketApplication.java  # Arranque Spring + JavaFX
    │   ├── config/                    # SecurityConfig (BCrypt)
    │   ├── modelos/                   # Entidades JPA
    │   ├── repository/                # Repositorios Spring Data JPA
    │   ├── service/ + service/imp/    # Lógica de negocio
    │   ├── Controladores/             # Controladores JavaFX
    │   ├── components/ · dto/ · utils/ · enums/
    │   └── Exeption/
    └── resources/
        ├── fxml/                      # 22 pantallas FXML
        ├── css/ · img/
        └── application.properties
```

---

## 🗃️ Base de datos

- Motor: **SQLite** (archivo `data/MiniMarket.db`).
- Tablas con prefijo `minimarket_`; Hibernate mantiene el esquema (`ddl-auto=update`).
- Contiene datos de ejemplo: usuarios, productos, categorías, ventas, etc.

---

## 📄 Documentación

En la carpeta `Documentacion/` se incluyen:

- **Manual de Usuario**
- **Descripción del Caso, Modelo y Arquitectura**
- **Investigación Aplicada**

---

## 👥 Equipo — Grupo G1

| Integrante | Rol |
|---|---|
| _(Completar nombre)_ | _(Completar rol)_ |
| _(Completar nombre)_ | _(Completar rol)_ |

> Curso a cargo del docente _(completar)_. UPeU — 2026-1.

---

## 📌 Notas

- Si el repositorio es **privado**, recuerde agregar como colaborador a **`dmamanipar`** (Settings → Collaborators).
- Proyecto con fines **académicos**.
