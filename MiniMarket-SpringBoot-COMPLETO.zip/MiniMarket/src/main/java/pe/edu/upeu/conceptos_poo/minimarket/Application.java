package pe.edu.upeu.conceptos_poo.minimarket;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Application {
    public static void main(String[] args) {
        ensureDataDirectoryExists();
        MiniMarketApplication.main(args);
    }

    private static void ensureDataDirectoryExists() {
        try {
            Files.createDirectories(Path.of("data"));
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo crear la carpeta de datos del programa.", e);
        }
    }
}
